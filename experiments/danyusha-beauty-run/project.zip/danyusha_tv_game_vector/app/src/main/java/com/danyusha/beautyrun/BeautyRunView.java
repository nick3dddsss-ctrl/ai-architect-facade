package com.danyusha.beautyrun;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.SystemClock;
import android.view.KeyEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class BeautyRunView extends View {
    private static final float VW = 1280f;
    private static final float VH = 720f;
    private static final float WORLD_W = 6200f;
    private static final float GROUND_Y = 620f;

    private static final int TITLE = 0;
    private static final int PLAYING = 1;
    private static final int PAUSED = 2;
    private static final int WON = 3;

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final ToneGenerator tones = new ToneGenerator(AudioManager.STREAM_MUSIC, 45);
    private final List<Platform> platforms = new ArrayList<>();
    private final List<BrushPickup> brushes = new ArrayList<>();
    private final List<Enemy> enemies = new ArrayList<>();
    private final Player player = new Player();

    private long lastFrame = SystemClock.uptimeMillis();
    private float cameraX = 0f;
    private float elapsed = 0f;
    private int state = TITLE;
    private int collected = 0;
    private int totalBrushes = 0;
    private int lives = 3;
    private boolean leftHeld;
    private boolean rightHeld;

    public BeautyRunView(Context context) {
        super(context);
        setFocusable(true);
        setFocusableInTouchMode(true);
        buildLevel();
        resetPlayer(false);
    }

    private void buildLevel() {
        platforms.clear();
        brushes.clear();
        enemies.clear();

        addPlatform(0, GROUND_Y, 900, 100);
        addPlatform(980, GROUND_Y, 650, 100);
        addPlatform(1710, GROUND_Y, 780, 100);
        addPlatform(2580, GROUND_Y, 520, 100);
        addPlatform(3180, GROUND_Y, 820, 100);
        addPlatform(4100, GROUND_Y, 620, 100);
        addPlatform(4800, GROUND_Y, 1400, 100);

        addPlatform(430, 500, 240, 28);
        addPlatform(760, 420, 220, 28);
        addPlatform(1180, 480, 240, 28);
        addPlatform(1510, 390, 220, 28);
        addPlatform(1930, 485, 280, 28);
        addPlatform(2270, 395, 220, 28);
        addPlatform(2750, 480, 220, 28);
        addPlatform(3090, 380, 260, 28);
        addPlatform(3490, 470, 270, 28);
        addPlatform(3870, 360, 230, 28);
        addPlatform(4300, 470, 260, 28);
        addPlatform(4680, 390, 220, 28);
        addPlatform(5050, 500, 250, 28);
        addPlatform(5420, 420, 260, 28);

        float[][] bp = {
                {240,545},{520,435},{845,355},{1080,545},{1260,415},
                {1575,325},{1830,545},{2040,420},{2320,330},{2670,545},
                {2820,415},{3200,315},{3410,545},{3580,405},{3935,295},
                {4200,545},{4390,405},{4740,325},{4930,545},{5150,435},
                {5510,355},{5790,545}
        };
        for (float[] b : bp) brushes.add(new BrushPickup(b[0], b[1]));
        totalBrushes = brushes.size();

        enemies.add(new Enemy(720,574,650,860));
        enemies.add(new Enemy(1330,574,1120,1510));
        enemies.add(new Enemy(2160,574,1850,2360));
        enemies.add(new Enemy(2870,574,2670,3030));
        enemies.add(new Enemy(3690,574,3340,3880));
        enemies.add(new Enemy(4490,574,4200,4620));
        enemies.add(new Enemy(5280,574,4980,5590));
    }

    private void addPlatform(float x, float y, float w, float h) {
        platforms.add(new Platform(x,y,w,h));
    }

    private void startGame() {
        collected = 0;
        lives = 3;
        buildLevel();
        resetPlayer(false);
        state = PLAYING;
        lastFrame = SystemClock.uptimeMillis();
        invalidate();
    }

    private void resetPlayer(boolean afterHit) {
        player.x = afterHit ? Math.max(80f, player.checkpointX) : 120f;
        player.y = 500f;
        player.vx = 0f;
        player.vy = 0f;
        player.onGround = false;
        player.facing = 1;
        cameraX = Math.max(0, player.x - 300f);
    }

    public void pauseGame() {
        if (state == PLAYING) state = PAUSED;
    }

    public void resumeGame() {
        lastFrame = SystemClock.uptimeMillis();
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        float sx = getWidth() / VW;
        float sy = getHeight() / VH;
        float scale = Math.min(sx, sy);
        float ox = (getWidth() - VW * scale) * 0.5f;
        float oy = (getHeight() - VH * scale) * 0.5f;

        canvas.save();
        canvas.translate(ox, oy);
        canvas.scale(scale, scale);

        long now = SystemClock.uptimeMillis();
        float dt = Math.min(0.034f, Math.max(0.001f, (now - lastFrame) / 1000f));
        lastFrame = now;
        elapsed += dt;

        if (state == PLAYING) update(dt);
        drawScene(canvas);

        if (state == TITLE) drawTitle(canvas);
        else if (state == PAUSED) drawPause(canvas);
        else if (state == WON) drawWin(canvas);

        canvas.restore();
        postInvalidateOnAnimation();
    }

    private void update(float dt) {
        float accel = 1550f;
        float maxSpeed = 360f;
        float friction = 1900f;

        if (leftHeld && !rightHeld) {
            player.vx -= accel * dt;
            player.facing = -1;
        } else if (rightHeld && !leftHeld) {
            player.vx += accel * dt;
            player.facing = 1;
        } else {
            if (player.vx > 0) player.vx = Math.max(0, player.vx - friction * dt);
            if (player.vx < 0) player.vx = Math.min(0, player.vx + friction * dt);
        }
        player.vx = clamp(player.vx, -maxSpeed, maxSpeed);

        player.vy += 1450f * dt;
        player.vy = Math.min(player.vy, 900f);

        float oldX = player.x;
        float oldY = player.y;
        player.x += player.vx * dt;
        player.x = clamp(player.x, 0, WORLD_W - player.w);
        resolveHorizontal(oldX);

        player.y += player.vy * dt;
        player.onGround = false;
        resolveVertical(oldY);

        if (player.y > VH + 240) loseLife();

        for (Enemy e : enemies) {
            if (!e.alive) continue;
            e.x += e.speed * e.dir * dt;
            if (e.x < e.minX) { e.x = e.minX; e.dir = 1; }
            if (e.x > e.maxX) { e.x = e.maxX; e.dir = -1; }

            if (overlap(player.x,player.y,player.w,player.h,e.x,e.y,e.w,e.h)) {
                float prevBottom = oldY + player.h;
                if (player.vy > 0 && prevBottom <= e.y + 18) {
                    e.alive = false;
                    player.vy = -520f;
                    tones.startTone(ToneGenerator.TONE_PROP_ACK, 80);
                } else {
                    loseLife();
                    break;
                }
            }
        }

        Iterator<BrushPickup> it = brushes.iterator();
        while (it.hasNext()) {
            BrushPickup b = it.next();
            float by = b.y + (float)Math.sin(elapsed * 4.5f + b.phase) * 7f;
            if (overlap(player.x,player.y,player.w,player.h,b.x-16,by-34,32,68)) {
                it.remove();
                collected++;
                tones.startTone(ToneGenerator.TONE_PROP_BEEP, 75);
            }
        }

        if (player.x > 5750) player.checkpointX = 5150;
        else if (player.x > 4100) player.checkpointX = 4100;
        else if (player.x > 2580) player.checkpointX = 2580;
        else if (player.x > 1710) player.checkpointX = 1710;
        else if (player.x > 980) player.checkpointX = 980;

        if (player.x + player.w > 6020f && player.y + player.h > 470f) {
            state = WON;
            player.vx = 0;
            tones.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 350);
        }

        float desired = player.x - 360f;
        cameraX += (desired - cameraX) * Math.min(1f, dt * 5.5f);
        cameraX = clamp(cameraX, 0, WORLD_W - VW);
    }

    private void resolveHorizontal(float oldX) {
        RectF r = new RectF(player.x,player.y,player.x+player.w,player.y+player.h);
        for (Platform q : platforms) {
            RectF pr = q.rect();
            if (!RectF.intersects(r,pr)) continue;
            if (oldX + player.w <= q.x + 4 && player.vx > 0) {
                player.x = q.x - player.w;
                player.vx = 0;
            } else if (oldX >= q.x + q.w - 4 && player.vx < 0) {
                player.x = q.x + q.w;
                player.vx = 0;
            }
            r.set(player.x,player.y,player.x+player.w,player.y+player.h);
        }
    }

    private void resolveVertical(float oldY) {
        RectF r = new RectF(player.x+5,player.y,player.x+player.w-5,player.y+player.h);
        for (Platform q : platforms) {
            RectF pr = q.rect();
            if (!RectF.intersects(r,pr)) continue;
            if (oldY + player.h <= q.y + 8 && player.vy >= 0) {
                player.y = q.y - player.h;
                player.vy = 0;
                player.onGround = true;
            } else if (oldY >= q.y + q.h - 6 && player.vy < 0) {
                player.y = q.y + q.h;
                player.vy = 0;
            }
            r.set(player.x+5,player.y,player.x+player.w-5,player.y+player.h);
        }
    }

    private void jump() {
        if (state == TITLE || state == WON) {
            startGame();
            return;
        }
        if (state == PAUSED) {
            state = PLAYING;
            lastFrame = SystemClock.uptimeMillis();
            return;
        }
        if (state == PLAYING && player.onGround) {
            player.vy = -650f;
            player.onGround = false;
            tones.startTone(ToneGenerator.TONE_PROP_PROMPT, 55);
        }
    }

    private void loseLife() {
        lives--;
        tones.startTone(ToneGenerator.TONE_SUP_ERROR, 160);
        if (lives <= 0) {
            state = TITLE;
            lives = 3;
            resetPlayer(false);
        } else {
            resetPlayer(true);
        }
    }

    private void drawScene(Canvas c) {
        drawBackground(c);
        c.save();
        c.translate(-cameraX,0);
        for (Platform q : platforms) drawPlatform(c,q);
        for (BrushPickup b : brushes) drawBrush(c,b);
        for (Enemy e : enemies) if (e.alive) drawEnemy(c,e);
        drawFinish(c);
        drawDanyusha(c);
        c.restore();
        drawHud(c);
    }

    private void drawBackground(Canvas c) {
        p.setShader(new LinearGradient(0,0,0,VH,0xFF72C6FA,0xFFFFE3EB,Shader.TileMode.CLAMP));
        c.drawRect(0,0,VW,VH,p);
        p.setShader(null);

        p.setColor(0xDFFFFFFF);
        for (int i=0;i<6;i++) {
            float x=100+i*250-((cameraX*0.08f)%250f);
            float y=90+(i%2)*42;
            c.drawCircle(x,y,42,p);
            c.drawCircle(x+42,y+8,34,p);
            c.drawCircle(x-38,y+12,28,p);
        }

        float far=cameraX*0.10f;
        for (int i=-1;i<10;i++) {
            float x=i*185-(far%185f);
            float base=568;
            float h=180+(i%3)*48;
            p.setColor(i%2==0?0xFFDDA8BD:0xFFE8BDD0);
            c.drawRoundRect(new RectF(x,base-h,x+132,base),18,18,p);
            p.setColor(0xFFCC7193);
            Path roof=new Path();
            roof.moveTo(x+24,base-h);
            roof.lineTo(x+66,base-h-68);
            roof.lineTo(x+108,base-h);
            roof.close();
            c.drawPath(roof,p);
            p.setColor(0xFFFFF2E4);
            for(int w=0;w<2;w++) for(int r=0;r<3;r++)
                c.drawRoundRect(new RectF(x+24+w*55,base-h+38+r*48,x+49+w*55,base-h+68+r*48),5,5,p);
        }

        float mid=cameraX*0.20f;
        for(int i=-1;i<7;i++) {
            float x=i*280-(mid%280f);
            p.setColor(0xFFF4CBD9);
            c.drawRoundRect(new RectF(x,460,x+230,605),28,28,p);
            p.setColor(0xFFE9AAC0);
            c.drawCircle(x+115,460,60,p);
        }

        p.setColor(0xFF6EA26E);
        c.drawRect(0,578,VW,720,p);
        p.setColor(0xFF4D8256);
        for(int i=0;i<14;i++) c.drawCircle(i*105-((cameraX*0.28f)%105f),580,31,p);

        p.setColor(0xCCB83B70);
        c.drawRoundRect(new RectF(985,150,1160,330),18,18,p);
        p.setColor(0xFFFFFFFF);
        p.setTextAlign(Paint.Align.CENTER);
        p.setFakeBoldText(true);
        p.setTextSize(25);
        c.drawText("BEAUTY",1072,215,p);
        c.drawText("CITY",1072,250,p);
        p.setTextSize(28);
        c.drawText("♛",1072,294,p);
        p.setFakeBoldText(false);
    }

    private void drawPlatform(Canvas c, Platform q) {
        boolean ground=q.y>=GROUND_Y;
        p.setColor(ground?0xFF312530:0xFF4A3544);
        c.drawRoundRect(q.rect(),14,14,p);

        p.setColor(ground?0xFFB94F78:0xFFD7678D);
        float face=ground?Math.min(52,q.h-10):Math.min(18,q.h);
        c.drawRoundRect(new RectF(q.x+4,q.y+5,q.x+q.w-4,q.y+face),10,10,p);

        p.setColor(0xFFE8B25E);
        c.drawRect(q.x+8,q.y+2,q.x+q.w-8,q.y+7,p);

        p.setColor(0xFFFFF0B2);
        float step=ground?76:58;
        for(float x=q.x+25;x<q.x+q.w-15;x+=step) c.drawCircle(x,q.y+19,ground?6.5f:4.5f,p);

        if(ground) {
            p.setColor(0xFF211923);
            c.drawRect(q.x+8,q.y+58,q.x+q.w-8,q.y+q.h-5,p);
        }
    }

    private void drawBrush(Canvas c, BrushPickup b) {
        float y=b.y+(float)Math.sin(elapsed*4.5f+b.phase)*7f;
        c.save();
        c.translate(b.x,y);
        c.rotate((float)Math.sin(elapsed*3f+b.phase)*8f);

        p.setColor(0xFFE8B25E);
        c.drawRoundRect(new RectF(-7,-4,7,20),4,4,p);
        p.setColor(0xFFC13F71);
        c.drawRoundRect(new RectF(-6,15,6,37),5,5,p);
        p.setColor(0xFF613645);
        Path tip=new Path();
        tip.moveTo(-13,-3);
        tip.quadTo(0,-34,13,-3);
        tip.close();
        c.drawPath(tip,p);

        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(3);
        p.setColor(0x88FFF5BA);
        c.drawCircle(0,2,31,p);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFFFFE98A);
        c.drawCircle(-28,-18,3,p);
        c.drawCircle(27,-12,2.5f,p);
        c.restore();
    }

    private void drawEnemy(Canvas c, Enemy e) {
        float bob=(float)Math.sin(elapsed*5+e.x*0.01f)*3;
        float x=e.x, y=e.y+bob;
        p.setColor(0xFF342735);
        c.drawRoundRect(new RectF(x,y,x+e.w,y+e.h),12,12,p);
        p.setColor(0xFFD95482);
        c.drawRoundRect(new RectF(x+5,y+5,x+e.w-5,y+e.h-7),9,9,p);
        p.setColor(0xFFFFD36E);
        Path crown=new Path();
        crown.moveTo(x+14,y+3); crown.lineTo(x+18,y-12); crown.lineTo(x+25,y-3);
        crown.lineTo(x+32,y-15); crown.lineTo(x+39,y+3); crown.close();
        c.drawPath(crown,p);
        p.setColor(0xFF241923);
        c.drawCircle(x+17,y+20,4,p);
        c.drawCircle(x+36,y+20,4,p);
        p.setStrokeWidth(3);
        p.setStyle(Paint.Style.STROKE);
        c.drawLine(x+13,y+14,x+22,y+18,p);
        c.drawLine(x+40,y+14,x+31,y+18,p);
        p.setStyle(Paint.Style.FILL);
    }

    private void drawFinish(Canvas c) {
        float x=6000;
        p.setColor(0x44FFD970);
        c.drawCircle(x+70,515,92,p);
        p.setColor(0xFFD64A77);
        c.drawRoundRect(new RectF(x+15,485,x+128,595),20,20,p);
        p.setColor(0xFFE8B25E);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(7);
        c.drawArc(new RectF(x+35,450,x+108,520),195,150,false,p);
        p.setStyle(Paint.Style.FILL);
        Path crown=new Path();
        crown.moveTo(x+45,535); crown.lineTo(x+52,512); crown.lineTo(x+65,528);
        crown.lineTo(x+78,506); crown.lineTo(x+91,528); crown.lineTo(x+104,512);
        crown.lineTo(x+110,535); crown.close();
        c.drawPath(crown,p);
        p.setColor(0xFFE8B25E);
        c.drawRect(x+150,430,x+158,615,p);
        p.setColor(0xFFD64A77);
        Path flag=new Path();
        flag.moveTo(x+158,438); flag.lineTo(x+232,452); flag.lineTo(x+158,487); flag.close();
        c.drawPath(flag,p);
    }

    private void drawDanyusha(Canvas c) {
        float x=player.x, y=player.y;
        float walk=player.onGround?(float)Math.sin(elapsed*12+player.x*0.03f):0;
        float runLean=Math.min(8,Math.abs(player.vx)*0.02f);

        c.save();
        c.translate(x+player.w/2,y+player.h/2);
        c.scale(player.facing,1);
        c.rotate(player.onGround?-player.facing*runLean*0.15f:player.facing*4);
        c.translate(-player.w/2,-player.h/2);

        // Hair
        p.setColor(0xFF39252E);
        c.drawOval(new RectF(6,-10,54,42),p);
        c.drawRoundRect(new RectF(5,22,22,65),9,9,p);
        c.drawOval(new RectF(38,12,60,42),p);

        // Face
        p.setColor(0xFFF0C5B2);
        c.drawOval(new RectF(16,2,45,39),p);
        p.setColor(0xFF222126);
        c.drawOval(new RectF(31,16,36,20),p);
        p.setColor(0xFF7A8B55);
        c.drawCircle(34,18,1.6f,p);
        p.setColor(0xFFC95F77);
        c.drawOval(new RectF(30,29,39,33),p);

        // Pink cropped jacket and white top
        p.setColor(0xFFD65D82);
        c.drawRoundRect(new RectF(10,38,48,69),8,8,p);
        p.setColor(0xFFFFEEE7);
        c.drawRoundRect(new RectF(22,40,36,67),5,5,p);
        p.setColor(0xFFE7B45C);
        c.drawCircle(16,48,2,p);

        // Arms
        float arm=player.onGround?walk*4:-5;
        p.setColor(0xFFF0C5B2);
        c.drawRoundRect(new RectF(5,42+arm,14,66+arm),5,5,p);
        c.drawRoundRect(new RectF(45,41-arm,54,65-arm),5,5,p);
        p.setColor(0xFF2C2430);
        c.drawRoundRect(new RectF(3,58+arm,15,68+arm),4,4,p);
        c.drawRoundRect(new RectF(44,56-arm,56,66-arm),4,4,p);

        // Makeup pouch
        p.setColor(0xFFC84D76);
        c.drawRoundRect(new RectF(45,57,58,73),4,4,p);
        p.setColor(0xFFE8B25E);
        c.drawCircle(51,65,2.5f,p);

        // Dark pants + pink stripe
        p.setColor(0xFF2C2830);
        c.drawRoundRect(new RectF(14,65,29,84),5,5,p);
        c.drawRoundRect(new RectF(31,65,46,84),5,5,p);
        p.setColor(0xFFE27A99);
        c.drawRect(18,67,21,82,p);
        c.drawRect(39,67,42,82,p);

        // Shoes
        float foot=player.onGround?walk*3:0;
        p.setColor(0xFFFFEEE9);
        c.drawRoundRect(new RectF(10+foot,80,31+foot,88),5,5,p);
        c.drawRoundRect(new RectF(28-foot,80,50-foot,88),5,5,p);
        p.setColor(0xFFD65D82);
        c.drawRect(15+foot,82,24+foot,85,p);
        c.drawRect(34-foot,82,43-foot,85,p);

        c.restore();
    }

    private void drawHud(Canvas c) {
        p.setColor(0xDD35263A);
        c.drawRoundRect(new RectF(20,18,448,92),22,22,p);

        p.setColor(0xFFD64A77);
        c.drawRoundRect(new RectF(30,27,178,83),16,16,p);
        p.setColor(0xFFFFFFFF);
        p.setTextSize(27);
        p.setTextAlign(Paint.Align.CENTER);
        p.setFakeBoldText(true);
        c.drawText("DANYUSHA",104,63,p);

        p.setTextAlign(Paint.Align.LEFT);
        p.setTextSize(27);
        c.drawText("🖌  "+collected+" / "+totalBrushes,195,64,p);
        p.setColor(0xFFFF5A88);
        String hearts="";
        for(int i=0;i<lives;i++) hearts+="♥";
        c.drawText(hearts,350,64,p);
        p.setFakeBoldText(false);

        p.setColor(0xB7352937);
        c.drawRoundRect(new RectF(900,24,1252,80),18,18,p);
        p.setColor(0xFFFFFFFF);
        p.setTextSize(20);
        p.setTextAlign(Paint.Align.CENTER);
        c.drawText("← → движение     OK прыжок",1076,59,p);
    }

    private void drawTitle(Canvas c) {
        p.setColor(0xB91B1420);
        c.drawRect(0,0,VW,VH,p);
        p.setTextAlign(Paint.Align.CENTER);
        p.setColor(0xFFFFFFFF);
        p.setFakeBoldText(true);
        p.setTextSize(76);
        c.drawText("ДАНЮША",VW/2,190,p);
        p.setColor(0xFFFF89AA);
        p.setTextSize(38);
        c.drawText("BEAUTY CITY ADVENTURE",VW/2,242,p);
        p.setFakeBoldText(false);

        drawMenuDanyusha(c,VW/2-35,300);

        p.setColor(0xFFFFFFFF);
        p.setTextSize(25);
        c.drawText("Собирай кисти, побеждай beauty-врагов и доберись до косметички",VW/2,505,p);

        p.setColor(0xFFD64A77);
        c.drawRoundRect(new RectF(460,550,820,620),24,24,p);
        p.setColor(0xFFFFFFFF);
        p.setFakeBoldText(true);
        p.setTextSize(31);
        c.drawText("OK — ИГРАТЬ",VW/2,596,p);
        p.setFakeBoldText(false);
        p.setTextSize(18);
        p.setColor(0xFFE8D9E2);
        c.drawText("Android TV: ← → движение  •  OK прыжок  •  Back пауза",VW/2,676,p);
    }

    private void drawMenuDanyusha(Canvas c, float x, float y) {
        c.save();
        c.translate(x,y);
        c.scale(1.55f,1.55f);
        p.setColor(0xFF39252E);
        c.drawOval(new RectF(6,-10,54,42),p);
        c.drawOval(new RectF(38,12,60,42),p);
        p.setColor(0xFFF0C5B2);
        c.drawOval(new RectF(16,2,45,39),p);
        p.setColor(0xFF7A8B55);
        c.drawCircle(34,18,2,p);
        p.setColor(0xFFD65D82);
        c.drawRoundRect(new RectF(10,38,48,69),8,8,p);
        p.setColor(0xFFFFEEE7);
        c.drawRoundRect(new RectF(22,40,36,67),5,5,p);
        p.setColor(0xFF2C2830);
        c.drawRoundRect(new RectF(14,65,29,84),5,5,p);
        c.drawRoundRect(new RectF(31,65,46,84),5,5,p);
        p.setColor(0xFFFFEEE9);
        c.drawRoundRect(new RectF(10,80,31,88),5,5,p);
        c.drawRoundRect(new RectF(28,80,50,88),5,5,p);
        c.restore();
    }

    private void drawPause(Canvas c) {
        p.setColor(0xAA1B151E);
        c.drawRect(0,0,VW,VH,p);
        p.setTextAlign(Paint.Align.CENTER);
        p.setColor(0xFFFFFFFF);
        p.setFakeBoldText(true);
        p.setTextSize(60);
        c.drawText("ПАУЗА",VW/2,335,p);
        p.setFakeBoldText(false);
        p.setTextSize(27);
        c.drawText("Нажми OK, чтобы продолжить",VW/2,395,p);
    }

    private void drawWin(Canvas c) {
        p.setColor(0xC51B151F);
        c.drawRect(0,0,VW,VH,p);
        p.setTextAlign(Paint.Align.CENTER);
        p.setColor(0xFFFF91AE);
        p.setFakeBoldText(true);
        p.setTextSize(58);
        c.drawText("ДАНЮША ДОШЛА ДО ФИНИША!",VW/2,255,p);
        p.setColor(0xFFFFFFFF);
        p.setTextSize(35);
        c.drawText("Кистей собрано: "+collected+" из "+totalBrushes,VW/2,325,p);
        p.setFakeBoldText(false);
        p.setTextSize(26);
        c.drawText(collected==totalBrushes?"Идеальный beauty-забег ✦":"Пройди ещё раз и собери все кисти",VW/2,382,p);
        p.setColor(0xFFD64A77);
        c.drawRoundRect(new RectF(455,440,825,515),24,24,p);
        p.setColor(0xFFFFFFFF);
        p.setFakeBoldText(true);
        p.setTextSize(30);
        c.drawText("OK — ЕЩЁ РАЗ",VW/2,488,p);
        p.setFakeBoldText(false);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        switch(keyCode) {
            case KeyEvent.KEYCODE_DPAD_LEFT:
                leftHeld=true; return true;
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                rightHeld=true; return true;
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_BUTTON_A:
                if(event.getRepeatCount()==0) jump();
                return true;
            case KeyEvent.KEYCODE_BACK:
                if(state==PLAYING) { state=PAUSED; return true; }
                if(state==PAUSED) { state=PLAYING; lastFrame=SystemClock.uptimeMillis(); return true; }
                break;
        }
        return super.onKeyDown(keyCode,event);
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        if(keyCode==KeyEvent.KEYCODE_DPAD_LEFT) { leftHeld=false; return true; }
        if(keyCode==KeyEvent.KEYCODE_DPAD_RIGHT) { rightHeld=false; return true; }
        return super.onKeyUp(keyCode,event);
    }

    private static boolean overlap(float ax,float ay,float aw,float ah,float bx,float by,float bw,float bh) {
        return ax<bx+bw && ax+aw>bx && ay<by+bh && ay+ah>by;
    }

    private static float clamp(float v,float lo,float hi) {
        return Math.max(lo,Math.min(hi,v));
    }

    private static class Platform {
        final float x,y,w,h;
        Platform(float x,float y,float w,float h) { this.x=x;this.y=y;this.w=w;this.h=h; }
        RectF rect() { return new RectF(x,y,x+w,y+h); }
    }

    private static class BrushPickup {
        final float x,y,phase;
        BrushPickup(float x,float y) { this.x=x;this.y=y;this.phase=(x*0.0137f+y*0.0073f)%6.28f; }
    }

    private static class Enemy {
        float x;
        final float y,w=52,h=46,minX,maxX;
        float speed=86;
        int dir=1;
        boolean alive=true;
        Enemy(float x,float y,float minX,float maxX) { this.x=x;this.y=y;this.minX=minX;this.maxX=maxX; }
    }

    private static class Player {
        float x,y,vx,vy;
        final float w=58,h=86;
        boolean onGround;
        int facing=1;
        float checkpointX=120;
    }
}
