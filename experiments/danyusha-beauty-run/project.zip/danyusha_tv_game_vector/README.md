# Данюша: Beauty City — Android TV prototype 0.2

Первый играбельный уровень для Android TV.

Управление:
- ← / → — движение
- OK / Enter / A — прыжок
- Back — пауза

В уровне:
- 22 кисти для макияжа
- 7 beauty-врагов
- 3 жизни
- контрольные точки
- финиш-косметичка
- оформление Beauty City

Сборка:
`gradle :app:assembleDebug`

APK:
`app/build/outputs/apk/debug/app-debug.apk`
